import asyncpg
import random
import string
import bcrypt
import base64
import io

from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from PIL import Image

app = FastAPI()

# -------------------------
# CORS LIBERADO
# -------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DATABASE_URL = "postgresql://neondb_owner:npg_C0NMgwQ1joHA@ep-rapid-voice-ac11wds0-pooler.sa-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require"

pool = None


# -------------------------
# GERAR IDS
# -------------------------

def gerar_user_id():
    chars = string.ascii_lowercase + string.digits
    return "BR" + "".join(random.choice(chars) for _ in range(4))


def gerar_produto_id():
    chars = string.ascii_lowercase + string.digits
    return "".join(random.choice(chars) for _ in range(5))


# -------------------------
# FORMATAR TELEFONE
# -------------------------

def formatar_telefone(numero):

    numero = ''.join(filter(str.isdigit, numero))

    if len(numero) != 11:
        raise ValueError("telefone invalido")

    ddd = numero[:2]
    parte1 = numero[2:7]
    parte2 = numero[7:]

    return f"+55 {ddd} {parte1}-{parte2}"


# -------------------------
# COMPRIMIR IMAGEM
# -------------------------

def comprimir_imagem(img_bytes):

    imagem = Image.open(io.BytesIO(img_bytes))
    imagem = imagem.convert("RGB")

    buffer = io.BytesIO()

    imagem.save(buffer, format="JPEG", quality=60, optimize=True)

    return buffer.getvalue()


# -------------------------
# AUTENTICAR USUARIO
# -------------------------

async def autenticar(conn, email, senha):

    user = await conn.fetchrow(
        "SELECT id, email, senha_hash, telefone, cidade, nome FROM users WHERE email=$1",
        email
    )

    if not user:
        raise HTTPException(401, "email invalido")

    if not bcrypt.checkpw(senha.encode(), user["senha_hash"].encode()):
        raise HTTPException(401, "senha invalida")

    return user


# -------------------------
# MODELOS
# -------------------------

class UserCreate(BaseModel):
    nome: str
    email: str
    senha: str
    telefone: str
    cidade: str


class Login(BaseModel):
    email: str
    senha: str


# -------------------------
# STARTUP
# -------------------------

@app.on_event("startup")
async def startup():

    global pool

    pool = await asyncpg.create_pool(
        DATABASE_URL,
        statement_cache_size=0
    )

    async with pool.acquire() as conn:

        await conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id VARCHAR(6) PRIMARY KEY,
            nome VARCHAR(100) NOT NULL,
            email VARCHAR(150) UNIQUE NOT NULL,
            senha_hash TEXT NOT NULL,
            telefone VARCHAR(20) NOT NULL,
            cidade VARCHAR(100) NOT NULL,
            data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """)

        await conn.execute("""
        CREATE TABLE IF NOT EXISTS produtos (
            id VARCHAR(5) PRIMARY KEY,
            user_id VARCHAR(6) REFERENCES users(id) ON DELETE CASCADE,
            preco NUMERIC NOT NULL,
            descricao TEXT,
            imagem BYTEA NOT NULL,
            data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """)


# -------------------------
# CRIAR CONTA
# -------------------------

@app.post("/criar-conta")
async def criar_conta(user: UserCreate):

    user_id = gerar_user_id()

    senha_hash = bcrypt.hashpw(
        user.senha.encode(),
        bcrypt.gensalt()
    ).decode()

    telefone = formatar_telefone(user.telefone)

    async with pool.acquire() as conn:

        try:
            await conn.execute("""
            INSERT INTO users (id,nome,email,senha_hash,telefone,cidade)
            VALUES ($1,$2,$3,$4,$5,$6)
            """,
            user_id,
            user.nome,
            user.email,
            senha_hash,
            telefone,
            user.cidade
            )

        except asyncpg.UniqueViolationError:
            raise HTTPException(400, "email ja existe")

    return {"id": user_id}


# -------------------------
# LOGIN
# -------------------------

@app.post("/login")
async def login(data: Login):

    async with pool.acquire() as conn:

        user = await autenticar(conn, data.email, data.senha)

    return {
        "id": user["id"],
        "email": user["email"]
    }


# -------------------------
# CRIAR PRODUTO
# -------------------------

@app.post("/produto/criar")
async def criar_produto(
    email: str = Form(...),
    senha: str = Form(...),
    preco: float = Form(...),
    descricao: str = Form(...),
    imagem: UploadFile = File(...)
):

    img_bytes = await imagem.read()
    img_comprimida = comprimir_imagem(img_bytes)

    async with pool.acquire() as conn:

        user = await autenticar(conn, email, senha)

        produto_id = gerar_produto_id()

        await conn.execute("""
        INSERT INTO produtos (id,user_id,preco,descricao,imagem)
        VALUES ($1,$2,$3,$4,$5)
        """,
        produto_id,
        user["id"],
        preco,
        descricao,
        img_comprimida
        )

    return {"produto_id": produto_id}


# -------------------------
# LISTAR PRODUTOS
# -------------------------

@app.get("/produtos")
async def listar_produtos():

    async with pool.acquire() as conn:

        rows = await conn.fetch("""
        SELECT 
        p.id,
        p.preco,
        p.descricao,
        p.imagem,
        u.nome,
        u.telefone,
        u.cidade
        FROM produtos p
        JOIN users u ON p.user_id=u.id
        ORDER BY p.data_criacao DESC
        """)

    produtos = []

    for r in rows:

        produtos.append({
            "id": r["id"],
            "nome_usuario": r["nome"],
            "preco": float(r["preco"]),
            "descricao": r["descricao"],
            "telefone": r["telefone"],
            "cidade": r["cidade"],
            "imagem": base64.b64encode(r["imagem"]).decode()
        })

    return produtos


# -------------------------
# PRODUTOS DE UM USUARIO
# -------------------------

@app.get("/produtos/usuario/{user_id}")
async def produtos_usuario(user_id: str):

    async with pool.acquire() as conn:

        rows = await conn.fetch("""
        SELECT 
        p.id,
        p.preco,
        p.descricao,
        p.imagem,
        u.nome,
        u.telefone,
        u.cidade
        FROM produtos p
        JOIN users u ON p.user_id=u.id
        WHERE u.id=$1
        """,
        user_id
        )

    produtos = []

    for r in rows:

        produtos.append({
            "id": r["id"],
            "nome_usuario": r["nome"],
            "preco": float(r["preco"]),
            "descricao": r["descricao"],
            "telefone": r["telefone"],
            "cidade": r["cidade"],
            "imagem": base64.b64encode(r["imagem"]).decode()
        })

    return produtos


# -------------------------
# OBTER UM PRODUTO
# -------------------------

@app.get("/produto/{produto_id}")
async def obter_produto(produto_id: str):

    async with pool.acquire() as conn:

        r = await conn.fetchrow("""
        SELECT 
        p.id,
        p.preco,
        p.descricao,
        p.imagem,
        u.nome,
        u.telefone,
        u.cidade
        FROM produtos p
        JOIN users u ON p.user_id=u.id
        WHERE p.id=$1
        """,
        produto_id
        )

    if not r:
        raise HTTPException(404, "produto nao encontrado")

    return {
        "id": r["id"],
        "nome_usuario": r["nome"],
        "preco": float(r["preco"]),
        "descricao": r["descricao"],
        "telefone": r["telefone"],
        "cidade": r["cidade"],
        "imagem": base64.b64encode(r["imagem"]).decode()
    }


# -------------------------
# APAGAR PRODUTO
# -------------------------

@app.delete("/produto/apagar")
async def apagar_produto(
    email: str,
    senha: str,
    produto_id: str
):

    async with pool.acquire() as conn:

        user = await autenticar(conn, email, senha)

        result = await conn.execute("""
        DELETE FROM produtos
        WHERE id=$1 AND user_id=$2
        """,
        produto_id,
        user["id"]
        )

    if result == "DELETE 0":
        raise HTTPException(404, "produto nao encontrado")

    return {"status": "produto apagado"}