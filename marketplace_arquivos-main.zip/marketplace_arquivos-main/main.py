import asyncpg
import random
import string
import bcrypt
import uuid

from datetime import datetime, timedelta

from jose import jwt, JWTError

from fastapi import (
    FastAPI,
    HTTPException,
    UploadFile,
    File,
    Form,
    Request,
    Response
)

from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from supabase import create_client

app = FastAPI()

# -------------------------
# CONFIGURAÇÕES
# -------------------------
SUPABASE_URL = "https://blutxeepiuvcgjmjbkag.supabase.co"

SUPABASE_KEY = "sb_secret_rn3Q9a4V3ciBbYcb9zJ8Iw_eYP5ZSFh"

BUCKET = "images"

supabase = create_client(SUPABASE_URL, SUPABASE_KEY)

DATABASE_URL = "postgresql://neondb_owner:npg_C0NMgwQ1joHA@ep-rapid-voice-ac11wds0-pooler.sa-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require"

JWT_SECRET = "sua_chave_super_secreta_aqui"
JWT_ALGORITHM = "HS256"
JWT_EXPIRE_DAYS = 2

pool = None

# -------------------------
# CORS
# -------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -------------------------
# FUNÇÕES AUXILIARES
# -------------------------
def gerar_user_id():
    chars = string.ascii_lowercase + string.digits
    return "BR" + "".join(random.choice(chars) for _ in range(4))


def gerar_produto_id():
    chars = string.ascii_lowercase + string.digits
    return "".join(random.choice(chars) for _ in range(5))


def formatar_telefone(numero):
    numero = ''.join(filter(str.isdigit, numero))

    if len(numero) != 11:
        raise ValueError("telefone invalido")

    return f"+55 {numero[:2]} {numero[2:7]}-{numero[7:]}"


async def autenticar(conn, email, senha):
    user = await conn.fetchrow(
        """
        SELECT id, email, senha_hash, telefone, cidade, nome, data_criacao
        FROM users
        WHERE email=$1
        """,
        email
    )

    if not user:
        raise HTTPException(401, "Credenciais invalidas")

    if not bcrypt.checkpw(
        senha.encode(),
        user["senha_hash"].encode()
    ):
        raise HTTPException(401, "Credenciais invalidas")

    return user


def criar_token(user_id: str):
    payload = {
        "user_id": user_id,
        "exp": datetime.utcnow() + timedelta(days=JWT_EXPIRE_DAYS)
    }

    token = jwt.encode(
        payload,
        JWT_SECRET,
        algorithm=JWT_ALGORITHM
    )

    return token


async def pegar_usuario_token(request: Request):
    token = request.cookies.get("token")

    if not token:
        raise HTTPException(401, "Nao autenticado")

    try:
        payload = jwt.decode(
            token,
            JWT_SECRET,
            algorithms=[JWT_ALGORITHM]
        )

        user_id = payload.get("user_id")

        if not user_id:
            raise HTTPException(401, "Token invalido")

    except JWTError:
        raise HTTPException(401, "Token invalido")

    async with pool.acquire() as conn:
        user = await conn.fetchrow(
            """
            SELECT id, email, telefone, cidade, nome, data_criacao
            FROM users
            WHERE id=$1
            """,
            user_id
        )

    if not user:
        raise HTTPException(401, "Usuario nao encontrado")

    return user

# -------------------------
# MODELOS
# -------------------------
class UserCreate(BaseModel):
    nome: str
    email: str
    senha: str
    telefone: str
    cidade: str


class Login(BaseModel):
    email: str
    senha: str

# -------------------------
# STARTUP
# -------------------------
@app.on_event("startup")
async def startup():
    global pool

    pool = await asyncpg.create_pool(
        DATABASE_URL,
        statement_cache_size=0
    )

    async with pool.acquire() as conn:

        await conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id VARCHAR(6) PRIMARY KEY,
            nome VARCHAR(100) NOT NULL,
            email VARCHAR(150) UNIQUE NOT NULL,
            senha_hash TEXT NOT NULL,
            telefone VARCHAR(20) NOT NULL,
            cidade VARCHAR(100) NOT NULL,
            data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """)

        await conn.execute("""
        CREATE TABLE IF NOT EXISTS produtos (
            id VARCHAR(5) PRIMARY KEY,
            user_id VARCHAR(6) REFERENCES users(id) ON DELETE CASCADE,
            nome VARCHAR(150),
            preco NUMERIC NOT NULL,
            descricao TEXT,
            imagem_url TEXT NOT NULL,
            data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """)

# -------------------------
# ROTAS DE USUÁRIO
# -------------------------
@app.post("/criar-conta")
async def criar_conta(user: UserCreate):

    user_id = gerar_user_id()

    senha_hash = bcrypt.hashpw(
        user.senha.encode(),
        bcrypt.gensalt()
    ).decode()

    async with pool.acquire() as conn:

        try:
            await conn.execute(
                """
                INSERT INTO users
                (id,nome,email,senha_hash,telefone,cidade)
                VALUES ($1,$2,$3,$4,$5,$6)
                """,
                user_id,
                user.nome,
                user.email,
                senha_hash,
                formatar_telefone(user.telefone),
                user.cidade
            )

        except asyncpg.UniqueViolationError:
            raise HTTPException(400, "email ja existe")

    return {
        "id": user_id
    }


@app.post("/login")
async def login(data: Login, response: Response):

    async with pool.acquire() as conn:
        user = await autenticar(
            conn,
            data.email,
            data.senha
        )

    token = criar_token(user["id"])

    response.set_cookie(
        key="token",
        value=token,
        httponly=True,
        secure=True,
        samesite="none",
        max_age=60 * 60 * 24 * 7
    )

    return {
        "status": "logado",
        "id": user["id"],
        "email": user["email"]
    }


@app.post("/logout")
async def logout(response: Response):

    response.delete_cookie("token")

    return {
        "status": "logout realizado"
    }


@app.get("/usuario/perfil")
async def perfil_usuario(request: Request):

    user = await pegar_usuario_token(request)

    return {
        "id": user["id"],
        "nome": user["nome"],
        "telefone": user["telefone"],
        "cidade": user["cidade"],
        "email": user["email"],
        "data_criacao": user["data_criacao"]
    }

# -------------------------
# ROTAS DE PRODUTOS
# -------------------------
@app.post("/produto/criar")
async def criar_produto(
    request: Request,
    nome: str = Form(...),
    preco: float = Form(...),
    descricao: str = Form(...),
    imagem: UploadFile = File(...)
):

    user = await pegar_usuario_token(request)

    async with pool.acquire() as conn:

        extensao = imagem.filename.split(".")[-1]

        nome_arquivo = f"{uuid.uuid4()}.{extensao}"

        conteudo = await imagem.read()

        supabase.storage.from_(BUCKET).upload(
            path=nome_arquivo,
            file=conteudo,
            file_options={
                "content-type": imagem.content_type
            }
        )

        url_imagem = supabase.storage.from_(BUCKET).get_public_url(
            nome_arquivo
        )

        pid = gerar_produto_id()

        await conn.execute(
            """
            INSERT INTO produtos
            (id,user_id,nome,preco,descricao,imagem_url)
            VALUES ($1,$2,$3,$4,$5,$6)
            """,
            pid,
            user["id"],
            nome,
            preco,
            descricao,
            url_imagem
        )

    return {
        "produto_id": pid,
        "url": url_imagem
    }


@app.get("/produtos")
async def listar_produtos():

    async with pool.acquire() as conn:

        rows = await conn.fetch(
            """
            SELECT
                p.*,
                u.nome as nome_usuario,
                u.telefone,
                u.cidade

            FROM produtos p

            JOIN users u
            ON p.user_id=u.id

            ORDER BY p.data_criacao DESC
            """
        )

    return [
        {
            "id": r["id"],
            "nome_produto": r["nome"],
            "nome_usuario": r["nome_usuario"],
            "preco": float(r["preco"]),
            "descricao": r["descricao"],
            "telefone": r["telefone"],
            "cidade": r["cidade"],
            "imagem_url": r["imagem_url"]
        }
        for r in rows
    ]

@app.get("/produtos/usuario")
async def produtos_usuario(request: Request):

    user = await pegar_usuario_token(request)

    async with pool.acquire() as conn:

        rows = await conn.fetch("""
        SELECT
            p.*,
            u.nome as nome_usuario,
            u.telefone,
            u.cidade

        FROM produtos p

        JOIN users u
        ON p.user_id=u.id

        WHERE u.id=$1

        ORDER BY p.data_criacao DESC
        """,
        user["id"]
        )

    return [
        {
            "id": r["id"],
            "nome_produto": r["nome"],
            "nome_usuario": r["nome_usuario"],
            "preco": float(r["preco"]),
            "descricao": r["descricao"],
            "telefone": r["telefone"],
            "cidade": r["cidade"],
            "imagem_url": r["imagem_url"]
        }
        for r in rows
    ]

@app.get("/produto/{produto_id}")
async def obter_produto(produto_id: str):

    async with pool.acquire() as conn:

        r = await conn.fetchrow(
            """
            SELECT
                p.*,
                u.nome as nome_usuario,
                u.telefone,
                u.cidade

            FROM produtos p

            JOIN users u
            ON p.user_id=u.id

            WHERE p.id=$1
            """,
            produto_id
        )

    if not r:
        raise HTTPException(404, "produto nao encontrado")

    return {
        "id": r["id"],
        "nome_produto": r["nome"],
        "nome_usuario": r["nome_usuario"],
        "preco": float(r["preco"]),
        "descricao": r["descricao"],
        "telefone": r["telefone"],
        "cidade": r["cidade"],
        "imagem_url": r["imagem_url"]
    }


@app.delete("/produto/apagar")
async def apagar_produto(
    request: Request,
    produto_id: str
):

    user = await pegar_usuario_token(request)

    async with pool.acquire() as conn:

        produto = await conn.fetchrow(
            """
            SELECT imagem_url
            FROM produtos
            WHERE id=$1 AND user_id=$2
            """,
            produto_id,
            user["id"]
        )

        if not produto:
            raise HTTPException(404, "produto nao encontrado")

        nome_arquivo = produto["imagem_url"].split("/")[-1]

        supabase.storage.from_(BUCKET).remove(
            [nome_arquivo]
        )

        await conn.execute(
            "DELETE FROM produtos WHERE id=$1",
            produto_id
        )

    return {
        "status": "produto apagado"
    }
